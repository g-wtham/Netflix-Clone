function  myclick() {
    window.alert("See you soon buddy!!")
}